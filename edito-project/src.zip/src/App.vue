<script>
export default {
  name: 'App',
}
</script>

<template>
  <RouterView />
  
</template>

<style></style>