<script>
import Sidebar from '../components/Sidebar.vue'

export default {
  name: 'App',
  components: {
    Sidebar
  }
}
</script>

<template>
    <h1>Génération de texte</h1>
    <div id="app">
    <Sidebar />
  </div>
</template>