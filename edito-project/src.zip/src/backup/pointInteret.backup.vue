<template>

</template>
<script>

    /*setup() {
        const count = ref(4);
        function increment() {
            if (count.value < 11) {
                count.value++;
                }
                }
                
                document.addEventListener("DOMContentLoaded", () => {
                    const button = document.querySelector(".add");
                    
                    function addPointInteret() {
                        const previousDiv = document.querySelector(".card-content-4");
                        let html = "<div class=\"card-content\"><h2 class=\"card-title\">Point d'intérêt n°4</h2><div class=\"box\"><textarea class=\"input-contenu\" type=\"text\" placeholder=\"Renseignez vos points d'intérêts\" maxlength=\"100\" rows=\"5\"></textarea></div></div>"
                        previousDiv.insertAdjacentHTML("afterend", html);
        }
        
        
        button.addEventListener("click", (e) => {
            if (count.value == 11) {
                e.preventDefault()
                } else {
                    addPointInteret()
            }
            });
            
            });
            return {
                count, increment
                }
                
                }, */
                
                        //addCard(e) {
        //    let CardObject = {
        //        id: this.contentCards.length + 1,
        //        classDiv1: "card-content",
        //        classH2: "card-title",
        //        title: "Point d'intérêt n°" + (this.contentCards.length + 1),
        //        classDiv2: "box",
        //        textareaClass: "input-contenu",
        //        vModel: this.contentCards.vModel,
        //        type: "text",
        //        placeholder: "Renseignez vos points d'intérêts",
        //        maxlength: "100",
        //        rows: "5"
        //    }
        //    if ((this.contentCards.length + 1) <= 10) {
        //        this.contentCards.push(CardObject)
        //    } else {
        //        e.preventDefault()
        //    }
        //},
</script>