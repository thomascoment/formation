// Exports the "silver" theme for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/themes/silver')
//   ES2015:
//     import 'tinymce/themes/silver'
require('./theme.js');