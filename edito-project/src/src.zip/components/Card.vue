<template>
    <div class="dashboard-cards">
        <div class="card-avance">
            <p class="titre">Avancée</p>
            <div class="texte">
                <p class="info">50</p>
                <p class="complement">pages remplies</p>
            </div>
        </div>

        <div class="card-taux">
            
            <p class="titre">Taux</p>
            <div class="texte">
                <p class="info">25 %</p>
                <p class="complement">effectué</p>
            </div>
        </div>

        <div class="card-reprendre">
            <p class="titre">Reprendre la saisie des points d'intérêts</p>
        </div>
    </div>
</template>

<script>

export default {
    name: 'Card',
}

</script>