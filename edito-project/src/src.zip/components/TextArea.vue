<template>
    <div class="card-content">
        <h2 class="card-title">Point d'intérêt n°1</h2>
        <div class="box">
            <textarea class="input-contenu" type="text" placeholder="Renseignez vos points d'intérêts" maxlength="100"
                rows="5"></textarea>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'TextArea'
    }
</script>